module.exports = require('./assignInWith');
